package com.example.watiread.watiread;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WatireadApplication {

	public static void main(String[] args) {
		SpringApplication.run(WatireadApplication.class, args);
	}

}
